﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd6
{
    /// <summary>
    /// Логика взаимодействия для addedit1.xaml
    /// </summary>
    public partial class addedit1 : Window
    {
        bd6Entities2 bd6Entities12 { get; set; }
        public addedit1(bd6Entities2 bd6Entities2, Admin admin)
        {
            InitializeComponent();
            bd6Entities12 = new bd6Entities2();
            this.DataContext = admin;
            this.bd6Entities12 = bd6Entities2;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            bd6Entities12.SaveChanges();
            Close();
        }
    }
}
