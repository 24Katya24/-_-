﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd6
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        bd6Entities2 bd { get; set; }
        public Window3()
        {
            InitializeComponent();
            bd = new bd6Entities2();
            bd6.ItemsSource = bd.Zayavka.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow f1 = new MainWindow();
            f1.Show();
            Close();

        }

        private void bd6_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var input = (sender as TextBox).Text.ToLower();
            if (!(String.IsNullOrEmpty(input)))
            {
                int resultCount = bd.Zayavka.Count(x => x.Description.Contains(input));
                bd6.ItemsSource = bd.Zayavka.Where(x => x.Description.Contains(input)).ToList();
                Title = $"База данных | Поиск: {input} | Результатов: {resultCount} из {bd.Zayavka.ToList().Count()}";
            }
            else
                ReadData();
        }
        public void ReadData()
        {
            bd = new bd6Entities2();
            bd6.ItemsSource = bd.Zayavka.ToList();
            Title = $"База данных";

        }
        private void Del_Click(object sender, RoutedEventArgs e)
        {
            var dea = bd6.SelectedItem as Zayavka;
            if (dea == null)
            {
                MessageBox.Show("Выберите строку", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            bd.Zayavka.Remove(dea);
            bd.SaveChanges();
            bd6.ItemsSource = bd.Zayavka.ToList();
            MessageBox.Show("Данные удалены");
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            Button red1 = sender as Button;
            var red2 = red1.DataContext as Zayavka;
            var red3 = new AddEdit3(bd, red2);
            red3.ShowDialog();
            bd6.ItemsSource = bd.Zayavka.ToList();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            var Dob = new Zayavka();
            bd.Zayavka.Add(Dob);
            var Dob1 = new AddEdit3(bd, Dob);
            Dob1.ShowDialog();
            bd6.ItemsSource = bd.Zayavka.ToList();
        }

        private void TextBox_TextChanged1(object sender, TextChangedEventArgs e)
        {

                ReadData1();
        }
        public void ReadData1()
        {
            bd = new bd6Entities2();
            bd6.ItemsSource = bd.Zayavka.ToList();
            Title = $"База данных";

        }

        private void MyDatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ButtonFilter_Click(object sender, RoutedEventArgs e)
        {
            DateTime? left = LeftDate.DisplayDate;
            DateTime? right = RightDate.DisplayDate;
            var list = bd.Zayavka.Where(x => x.Datest > left && x.Datest < right).ToList();
            bd6.ItemsSource = null;
            bd6.ItemsSource = list;
        }
    }
}
