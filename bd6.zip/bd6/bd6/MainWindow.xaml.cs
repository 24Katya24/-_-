﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bd6
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bd6Entities2 bd { get; set; }

        public MainWindow()

        {
            bd = new bd6Entities2();
            //InitializeComponent();
          
            //b1.ItemsSource = Add.InfoAdm.ToList();
            InitializeComponent();
            bd6.ItemsSource = bd.Admin.ToList(); /*Подключает базу данных к Grid*/
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window2 f1 = new Window2();
            f1.Show();
            Close();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window3 f1 = new Window3();
            f1.Show();
            Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var Dob = new Admin();
            bd.Admin.Add(Dob);
            var Dob1 = new addedit1(bd, Dob);
            Dob1.ShowDialog();
            bd6.ItemsSource = bd.Admin.ToList();
        }

        private void del(object sender, RoutedEventArgs e)
        {
            var dea = bd6.SelectedItem as Admin;
            if (dea == null)
            {
                MessageBox.Show("Выберите строку", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            bd.Admin.Remove(dea);
            bd.SaveChanges();
            bd6.ItemsSource = bd.Admin.ToList();
            MessageBox.Show("Данные удалены");
        }
        private void Edit_click(object sender, RoutedEventArgs e)
        {
            Button red1 = sender as Button;
            var red2 = red1.DataContext as Admin;
            var red3 = new addedit1(bd, red2);
            red3.ShowDialog();
            bd6.ItemsSource = bd.Admin.ToList();
        }
    }
}
