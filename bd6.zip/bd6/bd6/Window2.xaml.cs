﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd6
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        bd6Entities2 bd { get; set; }
        public Window2()
        {

            InitializeComponent();
            bd = new bd6Entities2();
            bd6.ItemsSource = bd.Klient.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow f1 = new MainWindow();
            f1.Show();
            Close();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var Dob = new Klient();
            bd.Klient.Add(Dob);
            var Dob1 = new addedit(bd, Dob);
            Dob1.ShowDialog();
            bd6.ItemsSource = bd.Klient.ToList();
        }
        private void del(object sender, RoutedEventArgs e)
        {
            var dea = bd6.SelectedItem as Klient;
            if (dea == null)
            {
                MessageBox.Show("Выберите строку", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            bd.Klient.Remove(dea);
            bd.SaveChanges();
            bd6.ItemsSource = bd.Klient.ToList();
            MessageBox.Show("Данные удалены");

        }
        private void Edit_click(object sender, RoutedEventArgs e)
        {
            Button red1 = sender as Button;
            var red2 = red1.DataContext as Klient;
            var red3 = new addedit(bd, red2);
            red3.ShowDialog();
            bd6.ItemsSource = bd.Klient.ToList();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var input = (sender as TextBox).Text.ToLower();
            if (!(String.IsNullOrEmpty(input)))
            {
                int resultCount = bd.Klient.Count(x => x.Surname.Contains(input));
                bd6.ItemsSource = bd.Klient.Where(x => x.Surname.Contains(input)).ToList();
                Title = $"База данных | Поиск: {input} | Результатов: {resultCount} из {bd.Klient.ToList().Count()}";
            }
            else
                ReadData();
        }
        public void ReadData()
        {
            bd = new bd6Entities2();
            bd6.ItemsSource = bd.Klient.ToList();
            Title = $"База данных";

        }
        private void Button_Click_21(object sender, RoutedEventArgs e)
        {
            MainWindow f1 = new MainWindow();
            f1.Show();
            Close();
        }
    }
}

    