﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd6
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        bd6Entities2 bd6;
        public Window1()
        {
            InitializeComponent();
            bd6 = new bd6Entities2();
            //Skip();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var userAuth = bd6.Users.FirstOrDefault(x => x.Login == login.Text && x.Password == Password.Password);
                if (userAuth == null)
                {
                    MessageBox.Show("Неверный логин или пароль попробуйте снова", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    switch (userAuth.Role)
                    {
                        case 1:
                            MessageBox.Show("Добро пожаловать!" + " " + userAuth.FIO);
                            Skip();
                            Close();

                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка" + ex.Message.ToString());
            }
            }

        private static void Skip()
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
