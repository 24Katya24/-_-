﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd6
{
    /// <summary>
    /// Логика взаимодействия для AddEdit3.xaml
    /// </summary>
    public partial class AddEdit3 : Window
    {
        bd6Entities2 bd { get; set; }
        bd6Entities2 bd6Entities12 { get; set; }
        public AddEdit3(bd6Entities2 bd6Entities2, Zayavka zayavka)
        {
            InitializeComponent();
            bd = new bd6Entities2();
            bd6.ItemsSource = bd.Klient.ToList();
            bd6Entities12 = new bd6Entities2();
            this.DataContext = zayavka;
            this.bd6Entities12 = bd6Entities2;
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            bd6Entities12.SaveChanges();
            Close();
        }
    }
}
